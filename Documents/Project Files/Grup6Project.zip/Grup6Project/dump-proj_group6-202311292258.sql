-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: proj_group6
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrive_staff`
--

DROP TABLE IF EXISTS `administrive_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrive_staff` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EMP_ID` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `EMP_ID` (`EMP_ID`),
  CONSTRAINT `administrive_staff_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrive_staff`
--

LOCK TABLES `administrive_staff` WRITE;
/*!40000 ALTER TABLE `administrive_staff` DISABLE KEYS */;
INSERT INTO `administrive_staff` VALUES (1,7),(2,8),(3,9),(4,10),(5,11);
/*!40000 ALTER TABLE `administrive_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `COURSE_NAME` varchar(50) NOT NULL,
  `TEXT_BOOK` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'DEFENSE AGAINST DARK ARTS',NULL),(3,'TURKISH101',NULL),(24,'Defense Against the Dark Arts','The Standard Book of Spells, Grade 1'),(25,'Potions and Elixirs','Advanced Potion-Making'),(26,'Magical Creatures Studies','Fantastic Beasts and Where to Find Them'),(27,'Quidditch Strategy','Quidditch Through the Ages'),(28,'Transfiguration Mastery','A Beginner\'s Guide to Transfiguration'),(29,'Charms and Enchantments','The Charmer\'s Guide'),(30,'Divination Techniques','Unfogging the Future'),(31,'History of Magic','A History of Magic'),(32,'Herbology Essentials','One Thousand Magical Herbs and Fungi'),(33,'Dark Arts Counter-Curses','Curses and Counter-Curses (Bewitch Your Friends and Befuddle Your Enemies)'),(34,'Magical Astronomy','The Night Sky in Magic'),(35,'Wizarding Law and Ethics','The Wizarding World Legal Guide'),(36,'Muggle Studies','Muggles: A Not-So-Magical Introduction'),(37,'Alchemy Secrets','Magick Moste Evile'),(38,'Ancient Runes Deciphering','Ancient Runes Made Easy'),(39,'Wandlore and Ollivanders','Wand Woods and Core Materials'),(41,'Magical Art and Music','Magical Water Plants of the Mediterranean'),(42,'Arithmancy Predictions','Numerology and Grammatica'),(43,'Wizarding Technology','The Wonders of Wizard Wireless'),(44,'Advanced Potion Making Of Anatolia','1001 Recipies Of Potions By Emine Beder');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_section`
--

DROP TABLE IF EXISTS `course_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_section` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `COURSE_ID` int DEFAULT NULL,
  `SECTION_NAME` varchar(50) NOT NULL,
  `TEACHER_ID` int DEFAULT NULL,
  `START_DATE` date NOT NULL,
  `END_DATE` date DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `COURSE_ID` (`COURSE_ID`),
  KEY `TEACHER_ID` (`TEACHER_ID`),
  CONSTRAINT `course_section_ibfk_1` FOREIGN KEY (`COURSE_ID`) REFERENCES `course` (`ID`),
  CONSTRAINT `TEACHER_ID` FOREIGN KEY (`TEACHER_ID`) REFERENCES `teacher` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_section`
--

LOCK TABLES `course_section` WRITE;
/*!40000 ALTER TABLE `course_section` DISABLE KEYS */;
INSERT INTO `course_section` VALUES (1,1,'1',1,'2023-01-01','2024-01-01'),(2,24,'1',3,'2023-01-01','2023-06-01'),(3,36,'1',3,'2023-01-01','2023-06-01'),(4,27,'1',3,'2023-01-01','2023-06-01'),(5,37,'1',4,'2023-01-01','2023-06-01'),(6,43,'1',5,'2023-01-01','2023-08-01'),(7,39,'1',6,'2023-01-01','2023-08-01'),(8,25,'1',7,'2023-01-01','2023-08-01'),(9,32,'1',8,'2023-01-01','2023-10-01'),(10,37,'1',5,'2023-01-01','2023-10-01'),(11,26,'1',4,'2023-01-01','2023-10-01'),(12,30,'1',7,'2023-01-01','2023-10-01'),(13,41,'1',5,'2023-01-01','2023-10-01'),(16,44,'1',5,'2023-01-01','2024-01-01'),(17,29,'1',9,'2023-01-01','2023-10-01');
/*!40000 ALTER TABLE `course_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `IS_FULLTIME` tinyint(1) NOT NULL,
  `FIRST_NAME` varchar(20) DEFAULT NULL,
  `LAST_NAME` varchar(20) DEFAULT NULL,
  `DATE_OF_BIRTH` date DEFAULT NULL,
  `SALARY` int NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,1,'PROFFESOR SEVERUS','SNAPE','1980-02-05',1200),(2,1,'John','Doe','1990-05-15',600),(3,1,'Jane','Smith','1985-11-28',750),(4,1,'Robert','Johnson','1993-03-02',550),(5,1,'Alice','Williams','1988-09-10',700),(6,1,'Michael','Brown','1995-07-20',60),(7,1,'Emily','Taylor','1992-08-17',65),(8,1,'Daniel','Anderson','1987-04-05',800),(9,1,'Olivia','Miller','1994-12-12',700),(10,1,'William','Davis','1989-06-25',75),(11,1,'Sophia','Jackson','1991-02-18',72),(12,1,'Minerva','McGonagall','1985-05-15',900),(13,1,'Severus','Snape','1980-01-09',1000),(14,1,'Filius','Flitwick','1980-10-17',2000),(15,1,'Pomona','Sprout','1985-05-15',500),(16,1,'Sybill','Trelawney','1988-03-09',1000),(17,1,'Gilderoy','Lockhart','1988-01-26',2500),(18,1,'Remus','Lupin','1980-03-10',2000),(19,1,'Alastor','Moody','1985-08-10',920),(20,1,'Dolores','Umbridge','1988-08-26',780),(21,1,'Rubeus','Hagrid','1985-12-06',4500);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `high_salary` BEFORE INSERT ON `employee` FOR EACH ROW BEGIN
   DECLARE max_salary INT;
   SELECT max(e.SALARY) INTO max_salary
   FROM employee e ;
 
  IF NEW.salary>max_salary THEN
       SIGNAL SQLSTATE '45000'
       SET MESSAGE_TEXT = 'salary cannot exceed Rubeus Hagrids salary.';
   END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `employee_activities`
--

DROP TABLE IF EXISTS `employee_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_activities` (
  `ACTIVITY_ID` int NOT NULL AUTO_INCREMENT,
  `EMP_ID` int DEFAULT NULL,
  `START_HOUR` time DEFAULT NULL,
  `DAY_OF_WEEK` varchar(10) DEFAULT NULL,
  `ACTIVITY_NAME` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`ACTIVITY_ID`),
  KEY `EMP_ID` (`EMP_ID`),
  CONSTRAINT `employee_activities_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_activities`
--

LOCK TABLES `employee_activities` WRITE;
/*!40000 ALTER TABLE `employee_activities` DISABLE KEYS */;
INSERT INTO `employee_activities` VALUES (1,1,'11:30:00','MONDAY','DEFATING_HARRY_POTTER'),(2,2,'14:30:00','SATURDAY','GYM'),(3,3,'15:30:00','TUESDAY','CHESS'),(4,4,'14:00:00','MONDAY','GYM'),(5,5,'13:00:00','SATURDAY','TRAVEL'),(6,6,'14:00:00','FRIDAY','FOOTBALL'),(7,7,'12:00:00','TUESDAY','CHESS'),(8,8,'17:00:00','WEDNESDAY','SWIMMING'),(10,19,'08:00:00','MONDAY','Game');
/*!40000 ALTER TABLE `employee_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense`
--

DROP TABLE IF EXISTS `expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expense` (
  `EXPENSE_ID` int NOT NULL AUTO_INCREMENT,
  `EXPENSE_NAME` varchar(20) DEFAULT NULL,
  `AMOUNT` int DEFAULT NULL,
  `EXPENSE_DATE` date DEFAULT NULL,
  PRIMARY KEY (`EXPENSE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense`
--

LOCK TABLES `expense` WRITE;
/*!40000 ALTER TABLE `expense` DISABLE KEYS */;
INSERT INTO `expense` VALUES (1,'rent',1000,'2022-01-01'),(2,'cleaning',500,'2022-01-02'),(3,'material',1100,'2022-02-11'),(4,'rent',1000,'2022-02-01'),(5,'rent',1000,'2022-04-01'),(6,'rent',1000,'2022-03-01'),(7,'rent',1000,'2022-04-01'),(8,'rent	',1200,'2022-05-01'),(9,'rent	',1200,'2022-06-01'),(10,'rent	',1200,'2022-07-01'),(11,'rent	',1200,'2022-08-01'),(12,'rent',1400,'2022-09-01'),(13,'rent',1400,'2022-10-01'),(14,'rent',1600,'2022-11-01'),(15,'rent',1600,'2022-12-01'),(16,'rent',1700,'2023-01-01'),(17,'rent',1800,'2023-02-01'),(18,'rent',1800,'2023-03-01'),(19,'rent',1800,'2023-04-01'),(20,'rent',1800,'2023-05-01'),(21,'rent',1800,'2023-06-01'),(22,'rent',2000,'2023-07-01'),(23,'rent',2000,'2023-08-01'),(24,'rent',2000,'2023-09-01'),(25,'rent',2000,'2023-10-01'),(26,'rent',2000,'2023-11-01'),(27,'Broken Window',400,'2023-11-05'),(28,'Bar Fight',400,'2023-11-05'),(29,'Smart Board',200,'2023-11-05'),(30,'Dumblodore_Fund ',50000,'2023-11-01'),(31,'Museum trip',2000,'2023-11-01'),(32,'Train tickets',500,'2023-11-01'),(33,'Bills',1000,'2023-11-01'),(34,'Smart Board',2000,'2023-10-01'),(35,'Museum trip',1000,'2023-10-01'),(36,'Dumblodore_Fund ',50000,'2023-10-08'),(37,'Car Rental',1500,'2023-10-09'),(38,'Birthday Celebration',300,'2023-10-11'),(39,'Restoration',550,'2023-10-09'),(40,'Gum',1,'2023-10-08'),(41,'invisibilty cloak',500,'2023-11-29');
/*!40000 ALTER TABLE `expense` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `high_expense` BEFORE INSERT ON `expense` FOR EACH ROW BEGIN
   DECLARE total_sum INT;
   SELECT SUM(AMOUNT) INTO total_sum
   FROM expense;
 
  IF total_sum + NEW.AMOUNT > 1000000 THEN
       SIGNAL SQLSTATE '45000'
       SET MESSAGE_TEXT = 'Total sum of the attribute exceeds 10';
   END IF;
  
  
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `guardian`
--

DROP TABLE IF EXISTS `guardian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian` (
  `STUDENT_ID` int NOT NULL,
  `FIRST_NAME` varchar(20) DEFAULT NULL,
  `LAST_NAME` varchar(20) DEFAULT NULL,
  `MAIL` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `CONTACT` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`STUDENT_ID`),
  CONSTRAINT `guardian_ibfk_1` FOREIGN KEY (`STUDENT_ID`) REFERENCES `student` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guardian`
--

LOCK TABLES `guardian` WRITE;
/*!40000 ALTER TABLE `guardian` DISABLE KEYS */;
INSERT INTO `guardian` VALUES (4,'James','Potter','james.potter@hogwards.com','+1234567890'),(5,'Emma','Granger','emma.granger@hogwards.com','+9876543210'),(6,'Arthur','Weasley','arthur.weasley@hogwards.com','+1122334455'),(7,'Xenophilius','Lovegood','x.lovegood@ehogwards.com','+9988776655'),(8,'Lucius','Malfoy','lucius.malfoy@hogwards.com','+1122334455'),(45,'Sevgi','Kaya','utkan@lekesiz.com','+905549087766'),(46,'Darth','Vader','kralvader@icloud.com','+991920'),(47,'Jerry','Smith','jsmith@ricknmorty.com','+120010912');
/*!40000 ALTER TABLE `guardian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `MATERIAL_NAME` varchar(20) DEFAULT NULL,
  `REMAINING` float DEFAULT NULL,
  `PRICE` int DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'kalem',9,100),(3,'tebeşir',4,14),(4,'asa',10,24),(5,'cetvel',4,99),(6,'invisibilty cloak',10,100),(7,'broomstick',80,100),(8,'pensieve',50,100),(9,'goblet of fire',50,22),(10,'Talking Paintings',60,33),(11,'Floo Powder',50,55),(12,'Howler',41,77),(13,'Time-Turner',22,89),(14,'sorting hat',33,99),(15,'magical compass',66,55),(16,'quiditch set',88,44),(19,'used cloak',55,6);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `low_asa` BEFORE UPDATE ON `inventory` FOR EACH ROW BEGIN
    DECLARE rem INT;
    SELECT REMAINING  INTO rem
    FROM inventory i  where i.MATERIAL_NAME ='asa'
   ; 
   
   IF new.REMAINING<5 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Remaining asa cannot be lower than 5';
    END if;
    
    
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `section_hours`
--

DROP TABLE IF EXISTS `section_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_hours` (
  `SEC_ID` int NOT NULL,
  `START_HOUR` time NOT NULL,
  `DAY_OF_WEEK` varchar(10) NOT NULL,
  PRIMARY KEY (`SEC_ID`,`START_HOUR`,`DAY_OF_WEEK`),
  CONSTRAINT `section_hours_ibfk_1` FOREIGN KEY (`SEC_ID`) REFERENCES `course_section` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_hours`
--

LOCK TABLES `section_hours` WRITE;
/*!40000 ALTER TABLE `section_hours` DISABLE KEYS */;
INSERT INTO `section_hours` VALUES (1,'08:30:00','MONDAY'),(1,'09:30:00','MONDAY'),(2,'10:30:00','MONDAY'),(2,'10:30:00','WEDNESDAY'),(2,'11:30:00','MONDAY'),(2,'11:30:00','WEDNESDAY'),(3,'11:30:00','THURSDAY'),(3,'12:30:00','THURSDAY'),(4,'08:30:00','THURSDAY'),(4,'10:30:00','THURSDAY'),(5,'13:30:00','MONDAY'),(5,'14:30:00','MONDAY'),(6,'15:30:00','FRIDAY'),(6,'16:30:00','FRIDAY'),(7,'12:30:00','TUESDAY'),(7,'13:30:00','TUESDAY'),(7,'14:30:00','TUESDAY'),(8,'11:30:00','FRIDAY'),(8,'12:30:00','FRIDAY'),(9,'14:30:00','WEDNESDAY'),(9,'15:30:00','WEDNESDAY'),(10,'08:30:00','FRIDAY'),(10,'09:30:00','FRIDAY'),(11,'12:30:00','WEDNESDAY'),(11,'13:30:00','WEDNESDAY'),(12,'15:30:00','MONDAY'),(12,'16:30:00','MONDAY'),(13,'08:30:00','THURSDAY'),(13,'09:30:00','THURSDAY'),(16,'08:30:00','TUESDAY'),(17,'17:30:00','TUESDAY');
/*!40000 ALTER TABLE `section_hours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `IS_ACTIVE` tinyint(1) NOT NULL,
  `FIRST_NAME` varchar(20) DEFAULT NULL,
  `LAST_NAME` varchar(20) DEFAULT NULL,
  `DATE_OF_BIRTH` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1,1,'UGUR','ZAKU','1993-09-02'),(2,1,'UTKU','LEKESİZ','1995-09-02'),(3,1,'Mehmet Taha','Demircan','2000-01-26'),(4,1,'Harry','Potter','2001-07-31'),(5,1,'Hermione','Granger','2000-09-19'),(6,1,'Ron','Weasley','2001-03-01'),(7,1,'Luna','Lovegood','2002-02-13'),(8,1,'Draco','Malfoy','2001-06-05'),(9,1,'Ginny','Weasley','2002-08-11'),(10,1,'Neville','Longbottom','2001-07-30'),(11,1,'Cho','Chang','2000-08-17'),(12,1,'Cedric','Diggory','1998-09-02'),(13,1,'Lavender','Brown','2000-11-21'),(14,1,'Seamus','Finnigan','2001-03-22'),(15,1,'Parvati','Patil','2000-02-20'),(16,1,'Dean','Thomas','2001-01-08'),(17,1,'Fred','Weasley','1999-04-01'),(18,1,'George','Weasley','1999-04-01'),(19,1,'Pansy','Parkinson','2001-02-14'),(20,1,'Blaise','Zabini','2000-06-06'),(21,1,'Nymphadora','Tonks','1996-12-26'),(22,1,'Sirius','Black JR','1997-11-03'),(23,1,'Remus','Lupin','1998-03-10'),(24,0,'Ahmed','Türk','1991-05-11'),(25,0,'Ali','Demir','1992-06-13'),(26,0,'Samed','Güngör','1990-08-16'),(27,0,'Rüstem','Gök','1993-04-09'),(28,0,'Ziya','Bayar','1990-11-11'),(29,1,'Oğulcan','Çetin','1995-07-12'),(44,1,'Turan','Kaya','1990-01-26'),(45,1,'Sinan','Kaya','2015-11-13'),(46,1,'Luke','Skywalker','1986-11-12'),(47,1,'Morty','Smith','2008-11-14');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `date_limit` BEFORE INSERT ON `student` FOR EACH ROW BEGIN
 
  IF (DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), NEW.DATE_OF_BIRTH)), '%Y') + 0)<20 THEN
       SIGNAL SQLSTATE '45000'
       SET MESSAGE_TEXT = 'Cannot add students below 5 years old.';
   END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `student_activities`
--

DROP TABLE IF EXISTS `student_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_activities` (
  `STUDENT_ID` int NOT NULL,
  `START_HOUR` time NOT NULL,
  `DAY_OF_WEEK` varchar(10) DEFAULT NULL,
  `ACTIVITY_NAME` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`STUDENT_ID`,`START_HOUR`),
  CONSTRAINT `student_activities_ibfk_1` FOREIGN KEY (`STUDENT_ID`) REFERENCES `student` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_activities`
--

LOCK TABLES `student_activities` WRITE;
/*!40000 ALTER TABLE `student_activities` DISABLE KEYS */;
INSERT INTO `student_activities` VALUES (1,'09:00:00','MONDAY','Math Club'),(2,'14:30:00','WEDNESDAY','Chess Club'),(3,'11:45:00','FRIDAY','Science Lab'),(4,'15:45:00','SATURDAY','Code Lab'),(5,'16:30:00','THURSDAY','Social Club'),(6,'17:00:00','MONDAY','Chess Club'),(7,'13:00:00','TUESDAY','Sport Club'),(8,'11:00:00','WEDNESDAY','Math Club'),(11,'12:30:00','TUESDAY','Surfing'),(18,'14:30:00','FRIDAY','minigolf'),(19,'08:00:00','MONDAY','Game');
/*!40000 ALTER TABLE `student_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_section`
--

DROP TABLE IF EXISTS `student_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_section` (
  `STUDENT_ID` int NOT NULL,
  `SECTION_ID` int NOT NULL,
  PRIMARY KEY (`STUDENT_ID`,`SECTION_ID`),
  KEY `SECTION_ID` (`SECTION_ID`),
  CONSTRAINT `student_section_ibfk_1` FOREIGN KEY (`STUDENT_ID`) REFERENCES `student` (`ID`),
  CONSTRAINT `student_section_ibfk_2` FOREIGN KEY (`SECTION_ID`) REFERENCES `course_section` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_section`
--

LOCK TABLES `student_section` WRITE;
/*!40000 ALTER TABLE `student_section` DISABLE KEYS */;
INSERT INTO `student_section` VALUES (4,2),(6,2),(8,2),(14,2),(16,2),(4,3),(6,3),(8,3),(12,3),(15,3),(20,3),(7,4),(5,5),(9,5),(10,5),(11,5),(16,5),(18,5),(21,5),(23,5),(9,6),(10,7),(19,7),(5,8),(7,8),(11,8),(19,8),(29,8),(47,8),(4,9),(13,10),(13,11),(14,11),(14,12),(17,12),(17,13),(15,16);
/*!40000 ALTER TABLE `student_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher`
--

DROP TABLE IF EXISTS `teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher` (
  `ID` int NOT NULL,
  `EMP_ID` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `EMP_ID` (`EMP_ID`),
  CONSTRAINT `teacher_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher`
--

LOCK TABLES `teacher` WRITE;
/*!40000 ALTER TABLE `teacher` DISABLE KEYS */;
INSERT INTO `teacher` VALUES (1,1),(2,12),(3,13),(4,14),(5,15),(6,16),(7,17),(8,18),(9,19),(10,20),(11,21);
/*!40000 ALTER TABLE `teacher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker`
--

DROP TABLE IF EXISTS `worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worker` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EMP_ID` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `EMP_ID` (`EMP_ID`),
  CONSTRAINT `worker_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `employee` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker`
--

LOCK TABLES `worker` WRITE;
/*!40000 ALTER TABLE `worker` DISABLE KEYS */;
INSERT INTO `worker` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6);
/*!40000 ALTER TABLE `worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'proj_group6'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-29 22:58:11
